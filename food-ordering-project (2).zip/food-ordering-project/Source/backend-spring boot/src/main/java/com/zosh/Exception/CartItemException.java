package com.zosh.Exception;

public class CartItemException extends Exception {
	
	public CartItemException(String message) {
		super(message);
	}

}

import React from 'react'
import RestaurantRequestTable from './RestaurantRequestTable'

const RestaurantRequest = () => {
  return (
    <div><RestaurantRequestTable name={"All Request"}/></div>
  )
}

export default RestaurantRequest